CS 3010 Programming Project 4
==============================
-The following program was meant to be run on PyCharm 2025 (Community Version was used). If it is not working, please run it on PyCharm and install the necessary packages and libraries as listed at the top of the program
-To change the original txt file used to calculate the values, change the line at the beginning of the Main function to read in a different string. For example, type in "input2.txt"